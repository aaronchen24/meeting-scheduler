// Disables form submission if username is taken
document.querySelector("form").onsubmit = function(event) {
    event.preventDefault();
    $.get("/check?username=" + document.getElementById("username").value, function(bool) {
        if (bool)
        {
            document.querySelector("form").submit();
        }
        else
        {
            alert("Username is taken!");
        }
    });
}